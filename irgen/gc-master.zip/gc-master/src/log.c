#include "log.h"

const char * log_level_strings [] = { "CRIT", "WARN", "INFO", "DEBG", "NONE" };

